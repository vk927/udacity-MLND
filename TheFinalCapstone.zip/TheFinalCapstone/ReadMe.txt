In this project we get the data from the kaggle data science website.

https://www.kaggle.com/c/two-sigma-connect-rental-listing-inquiries/data

we use sklearn library to work on machine learning models.
matplotlib is used for visualizations.
NLTK libraries for applying natural language processing.
Pandas and Numpy to work around dataframes in python, i.e for data munging in python.

the only thing you need to change in the project is to change the traing set file location,
please change it to your own location, where you get the train set downloaded.

the actual project is in the ipynb format , you need to install jupyter notebook software to 
get things done in order. you can get this from anaconda python distribution.

so overall you need to install anconda python distributuon (Numpy,pandas,matplotlib,sklearn 
and jupyternotebooks are included )and NLTK

if you open the .ipynb file which I provided using jupyter notebook,
 after that all the instructions and data are present in that book and you just need to fallow those.